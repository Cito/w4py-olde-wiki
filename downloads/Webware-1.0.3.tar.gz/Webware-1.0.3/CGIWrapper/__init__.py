# CGIWrapper package
# Webware for Python
# See Docs/index.html

def InstallInWebKit(appServer):
	pass
