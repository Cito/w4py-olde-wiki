"""Error.py

This program specifically imports a module with an unknown name,
which causes Python to throw an exception.  Consequently, you can
see how CGI Wrapper handles errors.

"""

import UnknownModuleName
