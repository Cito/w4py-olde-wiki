# Ian's Webware Wiki

__version__ = '0.2'