name = 'Components'

version = ('0', '1', 0)

docs = [{'name': "User's Guide", 'file': 'index.html'}]

status = 'beta'

requiredPyVersion = (2, 2, 0)

synopsis = """Components for Webware servlets"""

WebKitConfig = {
}
