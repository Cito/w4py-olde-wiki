from WebKit.Examples.ExamplePage import ExamplePage as WebKitExamplePage
from Component import CPage
from LoginKit import UserComponent
from LoginKit.pickleusermanager import PickleUserManager
from Component.notify import NotifyComponent
import os

userfiles = 'Cache/LoginKit/UserManager'
if not os.path.exists(userfiles):
    os.makedirs(userfiles)
manager = PickleUserManager(path=userfiles)

class ExamplePage(CPage, WebKitExamplePage):

    components = [UserComponent(manager), NotifyComponent()]

    def title(self):
        return CPage.title(self)

    def writeStyleSheet(self):
        WebKitExamplePage.writeStyleSheet(self)
        self.writeln('''<style type="text/css">
        .notifyMessage { border: thin solid black;
        margin: 6pt 0; padding: 2pt 4pt;
        background-color: #8c8; }
        .formError { border: thin solid black;
        margin: 6pt 0; padding: 2pt 4pt;
        background-color: #844; color: #fff; }
        </style>''')

    def writeBodyParts(self):
        wr = self.writeln
        wr('<table id="PageTable">')
        self.writeBanner()
        wr('<tr><td id="Sidebar">')
        self.writeSidebar()
        wr('</td>')
        wr('<td id="Content">')
        CPage.writeBodyParts(self)
        wr('</td>')
        wr('</tr></table>')

    def writeHeader(self):
        self.writeln('<h1>%s</h1>' % self.htTitle())
        self.writeMessages()

    def writeFooter(self):
        self.writeln('<br><hr noshade>')
        manager = self.userManager()
        users = manager.allUsers()
        for user in users:
            self.writeln('%s=%s<br>'
                % (user.username(), user.email()))
        if not users:
            self.writeln('<p>No users in system</p>')
