from ExamplePage import ExamplePage, manager

class CreateUser(ExamplePage):

    def loginRequired(self):
        return 0

    def awake(self, trans):
        ExamplePage.awake(self, trans)
        field = self.request().field
        if field('username', 0):
            if manager.userExists(field('username')):
                self.message('User %s already exists' % field('username'))
            else:
                user = manager.newUser()
                user.setUsername(field('username'))
                user.setPassword(field('password'))
                user.setEmail(field('email'))
                user.setName(field('name'))
                self.message('Created user %s' % field('username'))
                self.sendRedirectAndEnd('./')

    def writeContent(self):
        wr = self.writeln
        wr('<form action="CreateUser" method="POST">\n<table>')
        for name, type, length in [
            ('username', 'text', 20),
            ('name', 'text', 40),
            ('email', 'text', 40),
            ('password', 'password', 20),
            ('confirm', 'password', 20)]:
            wr('<tr><td><label for="%s">%s:</label></td>' % (name, name.capitalize()))
            wr('<td><input type="%s" name="%s" id="%s" size="%s" value="%s"></td></tr>'
                       % (type, name, name, length,
                          self.htmlEncode(self.request().field(name, ''))))
        wr('</table>')
        wr('<input type="submit" value="Create User">\n</form>')
