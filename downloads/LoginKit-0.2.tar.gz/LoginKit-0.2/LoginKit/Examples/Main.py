from ExamplePage import ExamplePage

class Main(ExamplePage):

    def title(self):
        return 'LoginKit Examples'

    def loginRequired(self):
        return 0
