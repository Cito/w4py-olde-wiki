from ExamplePage import ExamplePage

class Login(ExamplePage):

    def loginRequired(self):
        return 0 # better not be required...

    def writeContent(self):
        self.write(self.simpleLoginForm())
