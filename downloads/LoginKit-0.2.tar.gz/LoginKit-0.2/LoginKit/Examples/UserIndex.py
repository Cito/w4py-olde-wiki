from LoginKit.userindex import UserIndexComponent
from ExamplePage import ExamplePage

class UserIndex(ExamplePage):

    components = ExamplePage.components + [UserIndexComponent()]

    def loginRequired(self):
        return 0

    def writeStyleSheet(self):
        ExamplePage.writeStyleSheet(self)
        self.writeln('''
        <style type="text/css">
        .odd {background-color: #ddf}
        .even {background-color: #eef}
        .heading {background-color: #006; color: #fff}
        </style>
        ''')

    def writeContent(self):
        self.writeUserIndex()
