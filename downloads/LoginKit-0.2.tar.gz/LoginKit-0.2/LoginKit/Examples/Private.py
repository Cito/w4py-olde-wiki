from ExamplePage import ExamplePage

class Private(ExamplePage):

    def loginRequired(self):
        return 1

    def writeContent(self):
        self.writeln('<p>You have reached a private location.</p>')
        self.writeln('<p>Hello, %s!</p>'
            % (self.user().name() or self.user().username()))
