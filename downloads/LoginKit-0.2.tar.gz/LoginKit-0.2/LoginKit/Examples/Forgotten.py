from LoginKit.forgotten import ForgottenPasswordComponent
from ExamplePage import ExamplePage

class Forgotten(ExamplePage):

    components = ExamplePage.components + [ForgottenPasswordComponent()]

    def loginRequired(self):
        return 0

    def defaultAction(self):
        self.forgottenPasswordForm()

