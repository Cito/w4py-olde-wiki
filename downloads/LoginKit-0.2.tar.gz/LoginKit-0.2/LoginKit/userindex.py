from Component import Component, ServletComponent


class UserIndexServletComponent(ServletComponent):

    _servletMethods = ['writeUserIndex', 'deleteUser']

    def actions(self):
        return ['deleteUser']

    def writeUserIndex(self):
        manager = self.servlet().userManager()
        wr = self.servlet().writeln
        wr('<table><tr class="heading">')
        fields = [desc for desc in manager.userClass().fieldDescription
            if desc.get('readwrite', 'read') in ('read', 'readwrite')]
        for fieldDesc in fields:
            wr('<th>%s</th>\n' %
                fieldDesc.get('description', fieldDesc['field']))
        users = manager.allUsers()
        if users:
            wr('<th></th>')
        wr('</tr>')
        users.sort(lambda a, b: cmp(a.username(), b.username()))
        for index, user in enumerate(users):
            wr('<tr class="%s">'
                  % ['odd', 'even'][index%2])
            for fieldDesc in fields:
                wr('<td>%s</td>' % self.htmlEncode(
                    str(getattr(user, fieldDesc['field'])())))
            wr('<td>%s</td>' % self.controlsForUser(user))
            ('</tr>\n')
        if not users:
            wr('<tr class="even">')
            wr('<td colspan="%s" align="center">No users in system</td>'
                % len(manager.userClass().fieldDescription))
            wr('</tr>')
        wr('</table>')

    def deleteUser(self):
        userID = self.servlet().request().field('userID')
        try:
            userID = int(userID)
        except (ValueError, TypeError):
            # @@: this allows non-integer IDs, but implicitly based on
            # the request, which is maybe bad
            pass
        manager = self.servlet().userManager()
        user = manager.userForUserID(userID)
        username = user.username()
        user.delete()
        try:
            self.servlet().message('User %s deleted' % username)
        except AttributeError:
            pass
        self.servlet().sendRedirectAndEnd(self.servlet().linkToSelf())

    def controlsForUser(self, user):
        url = self.servlet().linkToSelf(args={
            '_action_': 'deleteUser',
            'userID': user.userID()})
        msg = 'Are you sure you want to delete the user %s?' % user.username()
        return ('<input type="button" value="delete"'
            'onClick="if (window.confirm(%s)) {window.location=%s}">'
            % (repr(msg), repr(url)))


class UserIndexComponent(Component):

    _componentClass = UserIndexServletComponent
