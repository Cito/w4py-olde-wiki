import sha, md5


############################################################
## Hash Functions
############################################################

def shaHash(s, salt):
    return sha.new(s + salt).hexdigest()

def md5Hash(s, salt):
    return md5.new(s + salt).hexdigest()

def noHash(s, salt):
    return s


class SimpleUser:
    """
    SimpleUser is a very simple implementation of a user, and an
    appropriate superclass for more complex implementations.
    """

    _hasher = shaHash

    fieldDescription = [
        {'field': 'username',
         'description': 'Username'},
        {'field': 'email',
         'description': 'Email'},
        {'field': 'name',
         'description': 'Real name'},
        {'field': 'password',
         'readwrite': 'write',
         'description': 'Password'},
        ]

    def __init__(self, manager):
        self._manager = manager
        self._username = None
        self._userID = None
        self._password = None
        self._email = None
        self._name = None

    def __repr__(self):
        args = []
        for fieldDesc in self.fieldDescription:
            if fieldDesc.get('readwrite', 'readwrite') in (
                'read', 'readwrite'):
                args.append(' %s=%r' % (fieldDesc['field'], getattr(self, fieldDesc['field'])()))
        return '<User %s%s>' % (self.userID(), ''.join(args))

    def setUsername(self, username):
        oldUsername = self.username()
        self._username = username
        self._manager.changeUsername(self, oldUsername)
        self.changed()

    def username(self):
        return self._username

    def email(self):
        return self._email

    def setEmail(self, value):
        self._email = value
        self.changed()

    def name(self):
        return self._name

    def setName(self, value):
        self._name = value
        self.changed()

    def setUserID(self, userID):
        assert self._userID is None
        self._userID = userID
        self.changed()

    def userID(self):
        return self._userID

    def hashPassword(self, password):
        return self._hasher.im_func(password, str(self._userID))

    def setPassword(self, password):
        self._password = self.hashPassword(password)
        self.changed()

    def passwordCorrect(self, password):
        return self.hashPassword(password) == self._password

    def __getstate__(self):
        # We don't want to pickle the manager, just this object...
        d = self.__dict__.copy()
        if d.has_key('_manager'):
            del d['_manager']
        return d

    def setUserManager(self, userManager):
        self._userManager = userManager

    def changed(self):
        self._manager.userChanged(self)

    def delete(self):
        self._manager.deleteUser(self)
        del self._manager
        del self._username
        del self._userID
        del self._password
        del self._email
        del self._name

    def simpleFields(self):
        """
        This is like pickle, but simpler; return a dictionary of
        'fields', each which has a string value.  Easy to serialize,
        future-compatible.  Feed back in with setSimpleFields(dict).
        """
        return {
            'username': self._username,
            'email': self._email,
            'password_hashed': self._password,
            'name': self._name,
            'id': str(self._userID),
            }

    def setSimpleFields(self, d):
        self._username = d['username']
        self._password = d['password_hashed']
        self._name = d.get('name', self._username)
        self._email = d.get('email', '')
        self._userID = int(d['id'])
