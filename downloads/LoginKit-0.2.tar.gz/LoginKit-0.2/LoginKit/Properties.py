name = 'LoginKit'

version = (0, 2, 0)

docs = []

status = 'alpha'

requiredPyVersion = (2, 2, 0)

synopsis = """Login and User component for Python"""

WebKitConfig = {
    'examplePages': [
        'CreateUser',
        'Login',
        'Private',
        'Forgotten',
        'UserIndex',
    ]
}
