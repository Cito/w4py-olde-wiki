import re

defaultUsernameRE = re.compile(r'^[a-zA-Z][a-zA-Z0-9_@\.\-]*$')


class UserExistsError(Exception):
    """
    Raised when there's an attempt to create a new user given a
    username that is already in use.
    """
    pass


class UserManager:
    """
    The UserManager creates and manages users in a system.  As such it
    also handles the identification phase, which usually implies
    password verification.
    """

    def __init__(self, usernameValidator=None,
             passwordValidator=None,
             usersConfidential=0):
        if usernameValidator:
            self.usernameValid = usernameValidator
        if passwordValidator:
            self.passwordValid = passwordValidator
        self._usersConfidential = usersConfidential

    def loginCorrect(self, username, password, request):
        return self.passwordCorrect(username, password)

    def passwordCorrect(self, username, password):
        if not self.userExists(username):
            return 0
        user = self.userForUsername(username)
        return user.passwordCorrect(password)

    def userExists(self, username):
        userID = self.userIDForUsername(username)
        return userID is not None

    def usernameInvalid(self, username):
        """
        This checks if a username is acceptable, not if it exists.
        Returns the error message if it is invalid; else None.
        """
        if not username:
            return 'Username must not be empty'
        if not defaultUsernameRE.search(username):
            return 'Username must start with a letter, and contain only letters, numbers, _, ., -, and @'
        return None

    def passwordInvalid(self, password):
        """
        This checks if a password is acceptable, not if it is correct.
        E.g., a policy where each password much have a non-letter
        character would be placed here.  Returns the error message if
        invalid; else None
        """
        if not password:
            return 'Your password must not be empty.'
        return None

    def usersConfidential(self):
        """
        If true, then usernames should not be revealed; specifically
        this is for bad logins.  If users are confidential, then the
        message would typically be 'username or password is incorrect',
        if users are not confidential than we can tell the user if
        the username they provided exists.
        """
        return self._usersConfidential

    def userForUsername(self, username):
        userID = self.userIDForUsername(username)
        if userID is None:
            return None
        return self.userForUserID(userID)

    def userForUserID(self, userID):
        return None

    def userIDForUsername(self, username):
        """
        External usernames and internal IDs are a separate concept;
        but in many systems they are identical (as in this default
        implementation).
        """
        return username

    def usernameForUserID(self, userID):
        return userID

    def userChanged(self, user):
        """
        This is called by the user objects whenever they are changed
        in a way that the UserManager should be aware of, e.g., if
        the UserManager is handling persistence.
        """
        pass

    def allUserIDs(self):
        """
        Returns a list of all user IDs.
        """
        raise NotImplementedError

    def allUsers(self):
        """
        Returns a list of all user objects.
        """
        return [self.userForUserID(userID)
                for userID in self.allUserIDs()]

    def userClass(self):
        raise NotImplementedError

    def userIDForUser(self, user):
        return user.userID()

    def usernameForUser(self, user):
        return user.username()
