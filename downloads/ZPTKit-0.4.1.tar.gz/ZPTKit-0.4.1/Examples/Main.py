from ZPTExample import ZPTExample

class Main(ZPTExample):

    pass
