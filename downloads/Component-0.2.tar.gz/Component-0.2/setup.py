# Set to true for a real release (otherwise the subversion version
# gets appended to the version):
RELEASE = True

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup
import warnings
warnings.filterwarnings("ignore", "Unknown distribution option")

import sys
# patch distutils if it can't cope with the "classifiers" keyword
if sys.version < '2.2.3':
    from distutils.dist import DistributionMetadata
    DistributionMetadata.classifiers = None
    DistributionMetadata.download_url = None

__version__ = '0.2'

def get_svn_revision():
    import commands, re, os
    status, output = commands.getstatusoutput(
        "svn info %s" % os.path.dirname(__file__))
    rev, date = 'unknown', 'unknown'
    match = re.search(r'Last Changed Rev: (\d+)', output)
    if match:
        rev = match.group(1)
    match = re.search(r'Last Changed Date: (.*)', output)
    if match:
        date = match.group(1).split()[0]
    return rev, date

if not RELEASE:
    rev, date = get_svn_revision()
    __version__ += 'a-svn-%s-%s' % (rev, date.replace('-', '_'))

setup(name="Component",
      version=__version__,
      description="Component system for Webware",
      long_description="""\
This package adds an alternative to Webware's ``WebKit.Page`` that
adds components and events, which make it possible to add
functionality to servlets without subclassing, and without clobbering
other reusable functionality.
""",
      classifiers=["Development Status :: 4 - Beta",
                   "Environment :: Web Environment",
                   "Intended Audience :: Developers",
                   "License :: OSI Approved :: MIT License",
                   "Programming Language :: Python",
                   "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
                   "Topic :: Software Development :: Libraries :: Python Modules",
                   ],
      author="Ian Bicking",
      author_email="ianb@colorstudy.com",
      url="http://wiki.w4py.org/component.html",
      license="MIT",
      packages=["Component"])

