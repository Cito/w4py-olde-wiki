from cpage import CPage
from component import Component, ServletComponent

def InstallInWebKit(appServer):
    pass
