name = 'Components'

version = (0, 2, 0)

docs = [{'name': "User's Guide", 'file': 'UsersGuide.html'}]

status = 'beta'

requiredPyVersion = (2, 2, 0)

synopsis = """Components for Webware servlets"""

WebKitConfig = {
}
