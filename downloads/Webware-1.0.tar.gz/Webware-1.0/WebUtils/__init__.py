# WebUtils
# Webware for Python
# See Docs/index.html

__all__ = ['Cookie', 'HTMLForException', 'HTTPStatusCodes', 'HTMLTag', 'Funcs']

def InstallInWebKit(appServer):
	pass
