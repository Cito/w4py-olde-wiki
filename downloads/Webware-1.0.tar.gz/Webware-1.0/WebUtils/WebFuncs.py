# Deprecated: We used to be called WebFuncs, now just Funcs.

print 'DEPRECATED: WebUtils.WebFuncs on 2001-02-24. Use WebUtils.Funcs instead.'

from Funcs import *
