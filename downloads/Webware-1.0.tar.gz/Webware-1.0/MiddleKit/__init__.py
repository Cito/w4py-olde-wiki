# MiddleKit
# Webware for Python
# See Docs/index.html

__all__ = ['Core', 'Design', 'Run']

def InstallInWebKit(appServer):
	pass
