# Set to true for a real release (otherwise the subversion version
# gets appended to the version):
RELEASE = True

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

import warnings
warnings.filterwarnings("ignore", "Unknown distribution option")

import sys
# patch distutils if it can't cope with the "classifiers" keyword
if sys.version < '2.2.3':
    from distutils.dist import DistributionMetadata
    DistributionMetadata.classifiers = None
    DistributionMetadata.download_url = None

__version__ = '0.1'

def get_svn_revision():
    import commands, re, os
    status, output = commands.getstatusoutput(
        "svn info %s" % os.path.dirname(__file__))
    rev, date = 'unknown', 'unknown'
    match = re.search(r'Last Changed Rev: (\d+)', output)
    if match:
        rev = match.group(1)
    match = re.search(r'Last Changed Date: (.*)', output)
    if match:
        date = match.group(1).split()[0]
    return rev, date

if not RELEASE:
    rev, date = get_svn_revision()
    __version__ += 'a-svn-%s-%s' % (rev, date.replace('-', '_'))

setup(name="LoginKit",
      version=__version__,
      description="Login management component for Webware",
      long_description="""\
LoginKit handles logins in Webware, using Component.  Servlets can add
authentication -- cookie and HTTP -- without changing their
inheritance or their logic.  Additional (optional) methods can be
added to servlets to indicate the needed permission level.

Authentication/identification is done with a separate UserManager
object, which abstracts out the identification source, as well as the
details of your user class.  Only minimal requirements are made of
your user and authentication system.
""",
      classifiers=["Development Status :: 4 - Beta",
                   "Environment :: Web Environment",
                   "Intended Audience :: Developers",
                   "License :: OSI Approved :: MIT License",
                   "Programming Language :: Python",
                   "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
                   "Topic :: Software Development :: Libraries :: Python Modules",
                   ],
      author="Ian Bicking",
      author_email="ianb@colorstudy.com",
      url="http://wiki.w4py.org/loginkit.html",
      license="MIT",
      packages=["LoginKit", "LoginKit.Examples"])

