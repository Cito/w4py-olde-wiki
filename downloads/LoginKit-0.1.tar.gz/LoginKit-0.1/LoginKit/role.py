class Role:

    _allRoles = {}

    def __init__(self, name, subRoles = None):
        self._name = name
        self._subRoles = subRoles or []
        self._allRoles[name] = self

    def roles(self):
        return self._subRoles

    def addRole(self, role):
        self._subRoles.append(role)

def roleByName(name):
    return Role._allRoles[name]


# examples:
# userRole = Role('user')
# managerRole = Role('manager', [userRole])
# godRole = Role('god', [managerRole])
