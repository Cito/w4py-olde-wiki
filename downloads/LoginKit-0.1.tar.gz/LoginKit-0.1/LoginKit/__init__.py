try:
    from pkg_resource import require
except ImportError:
    pass
else:
    require('Component')

from usermanager import UserManager
from simpleuser import SimpleUser
from usercomponent import UserComponent

def InstallInWebKit(appServer):
    pass
