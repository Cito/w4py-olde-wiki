import rfc822
import os
from pickleusermanager import PickleUserManager

class RFC822UserManager(PickleUserManager):
    
    def loadUserIDMap(self):
        filename = os.path.join(self._path, 'UserID-index.txt')
        d = {}
        try:
            f = open(filename)
        except (IOError, OSError):
            return d
        for line in f:
            line = line.strip()
            if not line:
                continue
            username, userID = line.split(':', 1)
            username = username.strip()
            userID = int(userID.strip())
            d[username] = userID
        f.close()
        return d

    def saveUserIDMap(self):
        filename = os.path.join(self._path, 'UserID-index.txt')
        f = open(filename, 'w')
        for username, userID in self._userIDMap.items():
            f.write('%s: %s\n' % (username, userID))
        f.close()

    def filenameForUserID(self, userID):
        return os.path.join(self._path, 'User-%i.txt' % userID)

    def userForUserID(self, userID):
        user = self._userClass(self)
        f = open(self.filenameForUserID(userID))
        fields = rfc822.Message(f)
        f.close()
        user.setSimpleFields(fields)
        return user

    def saveUser(self, user):
        fields = user.simpleFields()
        f = open(self.filenameForUserID(user.userID()), 'w')
        for name, value in fields.items():
            f.write('%s: %s\n' % (name, value))
        f.close()

