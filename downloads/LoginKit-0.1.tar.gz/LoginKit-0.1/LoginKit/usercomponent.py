import Component
from Component import ServletComponent, Component
from WebUtils.Funcs import htmlEncode, urlEncode
try:
    from paste.httpexceptions import *
    HTTPAuthenticationRequired = HTTPUnauthorized
    hasExceptions = True
except ImportError:
    try:
        from WebKit.HTTPExceptions import *
        hasExceptions = True
    except ImportError:
        hasExceptions = False

import base64

class UserServletComponent(ServletComponent):

    """
    Handles user login, creation, etc.  UserComponent should
    be used in your class definition.

    ``__init__`` takes a UserManager class (see the ``usermanager``
    module), and optionally the name of the servlet that implements
    the login page.  If httpLogin is true, then simple HTTP
    authentication is used instead of a login form.  If `saveUsername`
    is true, then the username will be saved in a cookie on login,
    and will be filled in when the user comes back to the site.

    ``loginEnvironKey`` is a key that is looked in for the username
    (like ``'REMOTE_USER'``).

    It adds the method ``user()`` to the servlet, which returns the
    logged in user or ``None`` (i.e., no logged in user).
    ``logout()`` logs the user out, and ``simpleLoginForm()`` returns
    as a string a simple login form (that you might embed in a
    sidebar).

    To ask a visitor to login, raise ``HTTPAuthenticationError``, or
    if the servlet defines the method ``loginRequired()``, and it
    returns 1, then the user will be required to login first.

    If ``userPermitted(user)`` is defined, then that will be called
    with the logged-in user, and ``HTTPForbidden`` will be raised if
    this method returns 0.

    If ``permittedRoles()`` is defined, then a match between those
    roles and the user's roles is searched for, and if not found
    ``HTTPForbidden`` will again be raised.

    If redirectAfterLogin is true (the default) and you login via a
    form (i.e., not HTTP authentication), then it may try to redirect
    to the page the user tried to get to originally.  You must add a
    key _actionLogin_REQUEST_METHOD to your form, with a value of
    'GET', as you can't redirect to a POST resource (in that case, no
    redirection will be done).  Any variables should be put in hidden
    fields, and (besides _actionLogin variables) they will be appended
    to the redirect URL.
    """

    def __init__(self, userManager, loginServlet='/Login', httpLogin=0,
                 realm="Secure Site", saveUsername=True,
                 redirectAfterLogin=True,
                 loginEnvironKey=None):
        self._userManager = userManager
        self._loginServlet = loginServlet
        self._httpLogin = httpLogin
        self._realm = realm
        self._saveUsername = saveUsername
        self._redirectAfterLogin = redirectAfterLogin
        self._loginEnvironKey = loginEnvironKey

    _servletMethods = ['user', 'setUser', 'simpleLoginForm', 'logout',
                       'userManager']

    if hasExceptions:
        _handleExceptions = [HTTPAuthenticationRequired]
    else:
        _handleExceptions = []

    def awakeEvent(self, trans):
        try:
            # If we already tried to authenticate, and this
            # is the login page, then we won't retry the
            # authentication
            if self.servlet().request()._loginForwarded:
                return True
        except AttributeError:
            pass
        req = self.servlet().request()
        if req.hasField('_actionLogout'):
            self.logout()
        if req.hasField('_actionLoginUsername_'):
            self.actionLogin()
        if (req.environ().get('HTTP_AUTHORIZATION')
            or req.environ().get('HTTP_CGI_AUTHORIZATION')):
            self.actionHTTPLogin()
        if self._loginEnvironKey:
            self.actionEnvironLogin()
        if self.optionalMethod('loginRequired', 1):
            self.loginRequired()
        if not self.optionalMethod('userPermitted', 1, self.user()):
            self.forbidden()
        roles = self.optionalMethod('permittedRoles', None)
        if roles is not None:
            if self.user() is None:
                self.actionLogin()
            if not self.roleAllowed(user, roles):
                self.forbidden()
        return True

    def forbidden(self):
        if hasExceptions:
            raise HTTPForbidden
        else:
            self.servlet().sendResponseAndEnd('403 Forbidden')

    def roleAllowed(self, role, allowedRoles):
        if role in allowedRoles:
            return 1
        for subRole in role.roles():
            if self.roleAllowed(subRole, allowedRoles):
                return 1
        return 0

    def actionLogin(self):
        req = self.servlet().request()
        field = req.field
        username = field('_actionLoginUsername_')
        password = field('_actionLoginPassword_')
        if self._userManager.loginCorrect(username, password, req):
            userID = self._userManager.userIDForUsername(username)
            self.setUser(userID, username)
            self.servlet().session().setValue('userID', userID)
            self.optionalMethod('message', None, 'Logged in as %s' % username)
        else:
            self.optionalMethod('message', None, 'Username or password incorrect')
        servlet = self.servlet()
        res = servlet.response()
        req = servlet.request()
        if (self._redirectAfterLogin
            and req.field('_actionLogin_REQUEST_METHOD', None) == 'GET'):
            url = servlet.linkToSelf()
            fields = []
            for name, value in req.fields().items():
                if (name.startswith('_actionLogin')
                    or name.startswith('_actionLogout')):
                    continue
                if isinstance(value, list):
                    for sub in value:
                        fields.append((name, sub))
                else:
                    fields.append((name, value))
            if fields:
                url += '?' + '&'.join(
                    ['%s=%s' % (urlEncode(name), urlEncode(value))
                     for name, value in fields])
            res.setHeader('Content-type', 'text/html')
            res.setHeader('Status', '303 Found')
            res.setHeader('Location', url)
            res.setHeader('Content-type', 'text/html')
            res.write('<html><head><title>302 Found</title></head><body><h1>Found</h1> For resource see: <a href="%s">%s</a></body></html>' % (url, url))
            servlet.endResponse()

    def actionHTTPLogin(self):
        req = self.servlet().request()
        environ = req.environ()
        auth = environ.get('HTTP_AUTHORIZATION',
                           environ.get('HTTP_CGI_AUTHORIZATION'))
        assert auth.lower().startswith('basic')
        auth = auth[5:].strip()
        auth = base64.decodestring(auth)
        username, password = auth.split(':', 1)
        if self._userManager.loginCorrect(username, password, req):
            userID = self._userManager.userIDForUsername(username)
            self.setUser(userID, username)
            self.servlet().session().setValue('userID', userID)
        else:
            self.authenticationRequired()

    def actionEnvironLogin(self):
        req = self.servlet().request()
        env = req.environ()
        if env.get(self._loginEnvironKey):
            username = env[self._loginEnvironKey]
            userID = self._userManager.userIDForUsername(username)
            self.setUser(userID, username)
            self.servlet().session().setValue('userID', userID)

    def authenticationRequired(self):
        if hasExceptions:
            raise HTTPAuthenticationRequired(self._realm)
        else:
            self.servlet().sendResponseAndEnd(
                '401 Authentication Required',
                headers={'WWW-Authenticate': 'Basic realm="%s"' % self._realm})

    def loginRequired(self):
        if not self.user():
            if self._httpLogin:
                self.authenticationRequired()
            else:
                self.servlet().request()._loginForwarded = 1
                self.servlet().application().forward(self.servlet().transaction(), self._loginServlet)

    def simpleLoginForm(self):
        req = self.servlet().request()
        username = req.field('_actionLoginUsername_', '')
        if not username:
            username = req.cookie('defaultUsername', '')
        return '''<form action="" method="post" name="_loginForm_">
<table class="loginForm"><tr><td>Username:</td>
<td><input type="text" name="_actionLoginUsername_" value="%s" size="20"></td></tr>
<tr><td>Password:</td>
<td><input type="password" name="_actionLoginPassword_" size="20"></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Login"></td></tr>
</table></form>
<script language="JavaScript"><!--
document.forms._loginForm_.elements.%s.focus()
//--></script>''' % \
    (htmlEncode(username),
     username and '_actionLoginPassword_' or '_actionLoginUsername_')

    def user(self):
        if not self.servlet().transaction().hasSession():
            return None
        if self.servlet().session().hasValue('userID'):
            return self._userManager.userForUserID(self.servlet().session().value('userID'))
        else:
            return None

    def setUser(self, user, username=None):
        if username is not None:
            userID = user
        elif isinstance(user, int):
            # Assume it's a user ID
            userID = user
            username = self._userManager.usernameForUserID(userID)
        elif isinstance(user, (str, unicode)):
            # Assume it's a username
            userID = self._userManager.userIDForUsername(user)
            username = user
        else:
            userID = self._userManager.userIDForUser(user)
            username = self._userManager.usernameForUser(user)
        self.servlet().session().setValue('userID', userID)
        self.servlet().response().setCookie('defaultUsername',
                                            username,
                                            expires='NEVER')

    def userManager(self):
        return self._userManager

    def logout(self):
        sess = self.servlet().session()
        if sess.hasValue('userID'):
            self.servlet().session().delValue('userID')

    def HTTPAuthenticationRequiredEvent(self, exc):
        self.loginRequired()
        return 'break'

class UserComponent(Component):

    _componentClass = UserServletComponent

