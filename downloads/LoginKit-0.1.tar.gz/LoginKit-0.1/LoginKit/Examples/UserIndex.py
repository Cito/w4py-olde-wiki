from LoginKit.userindex import UserIndexComponent
from ExamplePage import ExamplePage

class UserIndex(ExamplePage):

    components = ExamplePage.components + [UserIndexComponent()]

    def loginRequired(self):
        return False

    def writeContent(self):
        self.write('''
        <style type="text/css">
        .odd {background-color: #dddddd}
        .heading {background-color: #000066; color: #ffffff}
        </style>
        ''')
        self.writeUserIndex()
