from ExamplePage import ExamplePage

class Login(ExamplePage):

    def loginRequired(self):
        # better not be required...
        return 0

    def writeContent(self):
        self.write(self.simpleLoginForm())

