from ExamplePage import ExamplePage

class Private(ExamplePage):

    def loginRequired(self):
        return 1

    def writeContent(self):
        self.write('You have reached a private location!<p>\n')
        self.write('Hello %s' % self.user().username())
    
