from ExamplePage import ExamplePage, manager

class CreateUser(ExamplePage):

    def loginRequired(self):
        return 0

    def awake(self, trans):
        ExamplePage.awake(self, trans)
        field = self.request().field
        if field('username', 0):
            if manager.userExists(field('username')):
                self.message('User %s already exists' % field('username'))
            else:
                user = manager.newUser()
                user.setUsername(field('username'))
                user.setPassword(field('password'))
                user.setEmail(field('email'))
                user.setName(field('name'))
                self.message('Created user %s' % field('username'))
                self.sendRedirectAndEnd('./')

    def writeContent(self):
        self.write('<form action="" method="POST">\n<table>\n')
        for name, type, length in [
            ('username', 'text', 20),
            ('name', 'text', 40),
            ('email', 'text', 40),
            ('password', 'password', 20),
            ('confirm', 'password', 20)]:
            self.write('<tr><td>%s:</td>\n' % name.capitalize())
            self.write('<td><input type="%s" name="%s" size=%s value="%s"></td></tr>\n'
                       % (type, name, length,
                          self.htmlEncode(self.request().field(name, ''))))
        self.write('</table>')
        self.write('<input type="submit" value="Create User">\n</form>\n')
        
       
