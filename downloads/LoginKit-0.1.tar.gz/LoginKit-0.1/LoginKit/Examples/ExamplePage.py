#from Component import CPage
from WebKit.Examples.ExamplePage import ExamplePage as WebKitExamplePage
from Component import CPage
from LoginKit import UserComponent
from LoginKit.pickleusermanager import PickleUserManager
from Component.notify import NotifyComponent
import os

userfiles = '/tmp/usermanager'
if not os.path.exists(userfiles):
    os.makedirs(userfiles)
manager = PickleUserManager(path=userfiles)

class ExamplePage(WebKitExamplePage):

    components = [UserComponent(manager), NotifyComponent()]

    def title(self):
        return CPage.title(self)

    def writeBodyParts(self):
        wr = self.writeln
        wr('<table border=0 cellpadding=0 cellspacing=0 width=100%>')
        
        # banner
        self.writeBanner()
        
        # sidebar
        wr('<tr> <td bgcolor="#EEEEEF" valign=top nowrap>')
        self.writeSidebar()
        wr('</td>')
        
        # spacer
        wr('<td> &nbsp;&nbsp;&nbsp; </td>')
        
        # content
        wr('<td valign=top width=90%><p><br>')
        CPage.writeBodyParts(self)
        wr('</td>')
        
        # end
        wr('</tr> </table>')


    def writeHeader(self):
        self.write('''<style type="text/css">
        .notifyMessage { border: thin black solid;
          background-color: #aaffaa; }
        .formError { border: thin blacksolid;
          background-color: #660000; color: #ffffff; }
        </style>''')
        self.write('<h1>%s</h1>\n' % self.htTitle())
        self.writeMessages()

    def writeFooter(self):
        self.write('<hr noshade>\n')
        manager = self.userManager()
        users = manager.allUsers()
        for user in users:
            self.write('%s=%s<br>\n'
                       % (user.username(), user.email()))
        if not users:
            self.write('<p>No users in system</p>\n')

    
