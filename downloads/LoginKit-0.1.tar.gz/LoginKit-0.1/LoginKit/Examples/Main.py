from WebKit.Examples.ExamplePage import ExamplePage

class Main(ExamplePage):
    pass
