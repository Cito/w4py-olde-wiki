"""
Log a user in by checking a remote URL.

Right now this supports only HTTP Basic authentication.  This
specifically works against a remote Zope server.

Successful authentication is cached.
"""

import urlparse, httplib, base64, time

from LoginKit import UserManager, SimpleUser

class ProxyUser:

    """
    A particularly simple user -- since we don't host the user
    information, this only holds a barest stub of information.
    """

    def __init__(self, manager, username, userID, source):
        self._manager = manager
        self._username = username
        self._userID = userID
        self._source = source

    def username(self):
        return self._username

    def userID(self):
        return self._userID

    def __repr__(self):
        return '<%s username:%s>' % (self.__class__, self.username())

class ProxyUserManager(UserManager):

    def __init__(self, url, cacheTime=60, **kw):
        """
        url is the full URL (including http:// or https://) of the
        host that will be checked.

        Successful logins will be cached for cacheTime seconds.  This
        is particularly important if you are using HTTP authentication
        on the Webware side, as a login occurs for every request.

        If you want to use Webware HTTP authentication, be sure to
        pass httpLogin=1 to UserComponent, and you may wish to set the
        realm to the same realm as the URL uses.  If both Webware and
        the 'remote' authentication service are on the same domain,
        logins will carry over between the two.
        """
        UserManager.__init__(self, **kw)
        self._url = url
        self._authCheckCache = {}
        self._cacheTime = cacheTime

    def passwordCorrect(self, username, password):
        if self._authCheckCache.has_key(username):
            expireTime, cachePassword = self._authCheckCache[username]
            if expireTime <= time.time():
                return password == cachePassword
        result = self.authCheck(self._url, username, password)
        if result:
            self._authCheckCache[username] = (time.time() + self._cacheTime, password)
        return result

    def authCheck(self, url, username, password, allowRecur=1):
        """
        Checks auth_url to see if login we were given will work for this
        URL as well.  If not, we raise a 401 error, and trigger the client
        to give the same authorization (we using the same realm).
        """

        scheme, host, path, param, query, fragment = urlparse.urlparse(url)
        if scheme == 'http':
            Connection = httplib.HTTPConnection
        elif scheme == 'https':
            Connection = httplib.HTTPSConnection
        else:
            assert 0, "Unknown scheme: %r" % scheme

        if query:
            path = "%s?%s" % (path, query)

        conn = Connection(host)
        auth = base64.encodestring(username + ":" + password).strip()
        headers = {'Authorization': 'Basic ' + auth}

        conn.request("HEAD", path, '', headers)
        result = conn.getresponse()

        if result.status == 200:
            return 1
        if result.status >= 300 and result.status < 400:
            # Redirect
            # @@: maybe we should be signalling this as an error, as this
            # indicates a (somewhat) inaccurate configuration.
            if allowRecur:
                return self.authCheck(
                    result.getheader('location'), username, password,
                    allowRecur=0)
            # @@: Should we send a real error message?
            return 0
        else:
            return 0

    def userForUserID(self, userID):
        user = ProxyUser(self, username=userID, userID=userID,
                         source=self._url)
        return user

    def userIDForUsername(self, username):
        return username

    def usernameForUserID(self, userID):
        return userID

    def userChanged(self, user):
        pass
