# It should not be necessary, but in the following way
# you can configure xinha to appear in the current directory,
# though it is physically located in a separate directory:
# urlJoins = ['xinha/']

def contextInitialize(appServer, path):
    pass

