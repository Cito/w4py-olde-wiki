# TaskKit
# Webware for Python
# See Docs/index.html

def InstallInWebKit(appserver):
    pass
