"""Error.py

This program causes Python to throw an exception.
Consequently, you can see how CGI Wrapper handles errors.

"""

raise StandardError('Error example')
