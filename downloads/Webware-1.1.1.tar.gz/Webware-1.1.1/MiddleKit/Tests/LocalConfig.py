# LocalConfig.py
dbName = 'SQLite'
storeArgs = {'database': 'test.db'}
sqlCommand = 'python ExecuteScript.py "%s"'
sqlVersionCommand = 'python ExecuteScript.py --version'
# end