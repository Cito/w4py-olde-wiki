def CanRun():
    from MiscUtils import DataTable
    return DataTable.canReadExcel()
