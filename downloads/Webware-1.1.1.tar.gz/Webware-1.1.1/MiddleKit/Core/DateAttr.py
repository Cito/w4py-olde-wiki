from AnyDateTimeAttr import AnyDateTimeAttr


class DateAttr(AnyDateTimeAttr):

    def __init__(self, attr):
        AnyDateTimeAttr.__init__(self, attr)
