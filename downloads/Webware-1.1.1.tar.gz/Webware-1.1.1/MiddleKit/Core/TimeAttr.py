from AnyDateTimeAttr import AnyDateTimeAttr


class TimeAttr(AnyDateTimeAttr):

    def __init__(self, attr):
        AnyDateTimeAttr.__init__(self, attr)
