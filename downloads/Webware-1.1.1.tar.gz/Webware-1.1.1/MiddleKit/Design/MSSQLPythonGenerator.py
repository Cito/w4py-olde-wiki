from SQLPythonGenerator import SQLPythonGenerator


class MSSQLPythonGenerator(SQLPythonGenerator):
    pass
